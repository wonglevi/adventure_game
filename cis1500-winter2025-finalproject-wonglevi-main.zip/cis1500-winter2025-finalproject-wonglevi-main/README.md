Maze is a 2d array or arraylist of type Room:  5/5
Room class 5/5
Player class 5/5
NPC class 5/5
JavaFX program allows you to Search a room 5/5
JavaFX program allows you to Sleep in a room 5/5
JavaFX program allows you to Sleep in a room 5/5
JavaFX program allows you to fight an NPC 5/5
total 40/40
